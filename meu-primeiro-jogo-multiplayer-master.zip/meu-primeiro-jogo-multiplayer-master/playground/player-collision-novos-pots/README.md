<p></p>
<img src="https://camo.githubusercontent.com/450fecbc460a567a6c12f35d65a67bf3e6fd0d0e/68747470733a2f2f6d656469612e67697068792e636f6d2f6d656469612f5a43713833704363656b525963695a4d4c492f67697068792e676966"></img>

[![Player Collision no Gitpod](https://gitpod.io/button/open-in-gitpod.svg)](http://gitpod.io/#experiment=pwa-pod/https://github.com/doriclaudino/meu-primeiro-jogo-multiplayer)

<br>

<h3>new:</h3>
<ul>
<li>hit the border make you lost points (and can kill you)☠️☠️</li>
<li>dead players doens't play anymore</li>
<li>the pots colors and sizes is based on points on it's position</li>
<li>songs for differents events</li>
<li>you can hit players to kill them and get theirs dropped life points</li>
<li>the song is played for players based on it's position or if they are involved on event</li>
</ul>

<br>

<h3>todo:</h3>
<ul>
<li>add button to turn audio on/off 🎧🎧🎧</li>
<li>add button to turn pot values on/off (used for debug)</li>
<li>improve the players skins (we use a function to make it responsive)</li>
<li>add a crown on the top1 player (king?) 👑👑👑</li>
<li>better table for pots values</li>
<li>improve the rank table</li>
<li>add random shield (don't lost points) 🛡️🛡️🛡️</li>
<li>add super-power (on hit someone remove % of points instead fix points) 💪💪💪</li>
</ul>

<br>

<h3>ideas:</h3>
<ul>
<li>add speed (soo then we can create slow and speed-up powers)</li>
<li>create a sense of direction (the crashes can throw users based on directions)</li>
</ul>
